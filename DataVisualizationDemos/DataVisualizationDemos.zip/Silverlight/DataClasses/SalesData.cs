﻿using System;

namespace DataVisualizationDemos
{
    public class SalesData
    {
        public string Animal { get; set; }
        public int WestStoreQuantity { get; set; }
        public int EastStoreQuantity { get; set; }
    }
}
