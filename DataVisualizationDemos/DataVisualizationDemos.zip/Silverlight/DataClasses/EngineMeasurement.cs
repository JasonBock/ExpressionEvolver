﻿namespace DataVisualizationDemos
{
    public class EngineMeasurement
    {
        public int Speed { get; set; }
        public int Torque { get; set; }
        public int Power { get; set; }
    }
}
