﻿using System.Windows;

namespace DataVisualizationDemosWPF
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }
    }
}
