﻿using System.Windows;

namespace DataVisualizationDemosWPF
{
    public partial class App : Application
    {
    }
}
