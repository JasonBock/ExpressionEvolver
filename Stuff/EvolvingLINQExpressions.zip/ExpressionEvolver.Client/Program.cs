﻿using GeneticAlgorithm;
using Spackle;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace ExpressionEvolver.Client
{
	class Program
	{
		static void Main(string[] args)
		{
			Expression<Func<double, double>> func = a => ((Math.Pow(a, 0.5) * a * a) + a);
			//Expression<Func<double, double>> func = a => (a + a) * ((a + a) / (a * a));
			//Expression<Func<double, double>> func = a => a * a * a;
			//var func = new Func<double, double>(a => a + a + a + Math.Pow(a, 0.5) + (a * a * a));
			//var func = new Func<double, double>(a => a - (a - Math.Pow(a, 0.5) + (a * a * Math.Pow(a, 0.5)) - a));
			//var func = new Func<double, double>(a => a - (Math.Pow(a, 0.5)));
			//Expression<Func<double, double>> func = a => (4 - a) + (Math.Pow(a, 0.5) * 3);
			//Expression<Func<double, double>> func = a => (4 - a) + 3;
			//Expression<Func<double, double>> func = a => ((a / 4) - a) + (Math.Pow((33 * a), 0.5));
			//var func = new Func<double, double>(a => (1000 / Math.Pow(a, 0.5) * (a / 54)));
			//var func = new Func<double, double>(a => (((47 + (a * a) / (3 - a) + (Math.Pow(2, a))))));
			Console.Out.WriteLine("Target expression: " + func.ToString());
			var ga = new GeneticAlgorithm<Expression<Func<double, double>>>(
				new ExpressionEvolverGeneticAlgorithmParameters(func.Compile()));

			var generationCount = 1;
			var generationRunCount = 1;

			var generationRunCompletedHandler = new EventHandler<EventArgs<Population<Expression<Func<double, double>>>>>(
				(sender, e) =>
				{
					Program.PrintPopulation(e.Value, generationRunCount, "Run");
					generationRunCount++;
				});
			var generationCompletedHandler = new EventHandler<EventArgs<Population<Expression<Func<double, double>>>>>(
				(sender, e) =>
				{
					Program.PrintPopulation(e.Value, generationCount, "Generation");
					generationCount++;
				});

			ga.GenerationCompleted += generationCompletedHandler;
			ga.GenerationRunCompleted += generationRunCompletedHandler;
			ga.Run();
			ga.GenerationCompleted -= generationCompletedHandler;
			ga.GenerationRunCompleted -= generationRunCompletedHandler;
			Console.Out.WriteLine(ga.WasOptimalSolutionFound);
			var best = (from chromosome in ga.Final.Chromosomes
							orderby chromosome.Chromosome.Fitness descending
							select chromosome.Chromosome).Take(1).FirstOrDefault();
			Console.Out.WriteLine(best.Value.ToString());
		}

		private static void PrintPopulation(Population<Expression<Func<double, double>>> population, int generationCount, string type)
		{
			var best = (from chromosome in population.Chromosomes
							orderby chromosome.Chromosome.Fitness descending
							select chromosome.Chromosome).Take(1).FirstOrDefault();
			Console.Out.WriteLine(type + " " + generationCount + "," + population.FitnessSummary + "," +
				population.FitnessAverage + "," + best.Fitness + ", " + best.Value.ToString());
		}
	}
}
