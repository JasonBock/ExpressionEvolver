﻿using Spackle;
using System;

namespace GeneticAlgorithm
{
	public class Chromosome<T>
	{
		public Chromosome(T value, Func<T, double> fitnessEvaluator)
			: base()
		{
			this.Value = value;
			this.Fitness = fitnessEvaluator(value);
		}

		public double Fitness
		{
			get;
			private set;
		}

		public T Value
		{
			get;
			set;
		}

		public override string ToString()
		{
			return this.Value.ToString() + ", Fitness = " + this.Fitness.ToString();
		}
	}
}
