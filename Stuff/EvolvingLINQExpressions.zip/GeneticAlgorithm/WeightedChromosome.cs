﻿using Spackle;
using System;

namespace GeneticAlgorithm
{
	public sealed class WeightedChromosome<T>
	{
		public WeightedChromosome(Chromosome<T> chromosome, Range<double> fitnessWeight)
			: base()
		{
			this.Chromosome = chromosome;
			this.FitnessWeight = fitnessWeight;
		}
		
		public Chromosome<T> Chromosome
		{
			get;
			private set;
		}

		public Range<double> FitnessWeight
		{
			get;
			private set;
		}

		public override string ToString()
		{
			return this.Chromosome.ToString() + ", Weight = " + this.FitnessWeight.ToString();
		}
	}
}
