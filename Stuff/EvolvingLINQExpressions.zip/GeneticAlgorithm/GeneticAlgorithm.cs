﻿using Spackle;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace GeneticAlgorithm
{
	public sealed class GeneticAlgorithm<T>
	{
		public event EventHandler<EventArgs<Population<T>>> GenerationRunCompleted;
		public event EventHandler<EventArgs<Population<T>>> GenerationCompleted;

		public GeneticAlgorithm(IGeneticAlgorithmParameters<T> paramaters)
		{
			this.Parameters = paramaters;
		}

		public void Run()
		{
			var population = this.Parameters.GeneratePopulation();

			var solution = this.Parameters.Terminator(population);
			var runCount = 0;

			while(solution == null && runCount < this.Parameters.NumberOfGenerationRuns)
			{
				population = this.RunGeneration(population);

				if(this.GenerationRunCompleted != null)
				{
					this.GenerationRunCompleted(this, new EventArgs<Population<T>>(population));
				}

				solution = this.Parameters.Terminator(population);
				runCount++;
			}

			this.WasOptimalSolutionFound = solution != null;
			this.Final = population;
		}

		private Population<T> RunGeneration(Population<T> population)
		{
			Population<T> generationPopulation = population;

			var random = new SecureRandom();

			for(var i = 0; i < this.Parameters.NumberOfGenerations; i++)
			{
				var chromosomes = new List<Chromosome<T>>(
					from fitChild in this.Parameters.SelectFittestChildren(generationPopulation)
					select new Chromosome<T>(
						this.Parameters.Mutator(fitChild.Value), this.Parameters.FitnessEvaluator));

				do
				{
					var parents = this.Parameters.SelectParents(generationPopulation);

					ReadOnlyCollection<T> children = null;

					if(random.NextDouble() < this.Parameters.CrossoverProbability)
					{
						children = this.Parameters.Crossover(parents);
					}
					else
					{
						children = new List<T>(from parent in parents
													  select parent.Value).AsReadOnly();
					}

					foreach(var child in children)
					{
						var chromosome = new Chromosome<T>(
							this.Parameters.Mutator(child), this.Parameters.FitnessEvaluator);
						
						if(!double.IsInfinity(chromosome.Fitness))
						{
							chromosomes.Add(new Chromosome<T>(
								this.Parameters.Mutator(child), this.Parameters.FitnessEvaluator));						
						}
					}
				} while(chromosomes.Count < generationPopulation.Chromosomes.Count);

				generationPopulation = new Population<T>(new List<Chromosome<T>>(
					chromosomes.Take(generationPopulation.Chromosomes.Count)));

				if(this.GenerationCompleted != null)
				{
					this.GenerationCompleted(this, new EventArgs<Population<T>>(generationPopulation));
				}
				
				if(this.Parameters.Terminator(generationPopulation) != null)
				{
					break;
				}
			}

			return generationPopulation;
		}

		public Population<T> Final
		{
			get;
			private set;
		}

		public IGeneticAlgorithmParameters<T> Parameters
		{
			get;
			private set;
		}

		public bool WasOptimalSolutionFound
		{
			get;
			private set;
		}
	}
}
