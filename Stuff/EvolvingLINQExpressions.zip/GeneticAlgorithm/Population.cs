﻿using Spackle;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace GeneticAlgorithm
{
	public sealed class Population<T>
	{
		public Population(IList<Chromosome<T>> chromosomes)
		{
			this.FitnessSummary = (double)(from chromosome in chromosomes
													 select chromosome.Fitness).Sum();
			this.FitnessAverage = this.FitnessSummary / chromosomes.Count;
			
			var weightedChromosomes = new List<WeightedChromosome<T>>();
			
			var fitnessWeightOffset = 0d;

			for(var j = 0; j < chromosomes.Count; j++)
			{
				var chromosome = chromosomes[j];
				var fitnessWeight = (double)chromosome.Fitness / this.FitnessSummary;
				var weight = new Range<double>(
					fitnessWeightOffset, fitnessWeightOffset + fitnessWeight);
				fitnessWeightOffset += fitnessWeight;

				if(fitnessWeightOffset > 1d)
				{
					fitnessWeightOffset = 1d;
				}
				else if(j == chromosomes.Count - 1 && fitnessWeightOffset < 1d)
				{
					fitnessWeightOffset = 1d;
				}
			
				weightedChromosomes.Add(new WeightedChromosome<T>(chromosome, weight));	
			}
			
			this.Chromosomes = weightedChromosomes.AsReadOnly();
		}

		public ReadOnlyCollection<WeightedChromosome<T>> Chromosomes
		{
			get;
			private set;
		}

		public double FitnessAverage
		{
			get;
			private set;
		}

		public double FitnessSummary
		{
			get;
			private set;
		}
	}
}
