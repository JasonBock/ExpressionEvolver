﻿using ExpressionEvolver;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Spackle.Testing;
using System;
using System.Linq.Expressions;

namespace ExpressionEvolver.Tests
{
	[TestClass]
	public sealed class ExpressionExtensionsTests : CoreTests
	{
		[TestMethod]
		public void ReduceWithDivideSameDividentAndDivisor()
		{
			// a => ((a + 3) / (a + 3))
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Divide(
				Expression.Add(parameter, Expression.Constant(3d)),
				Expression.Add(parameter, Expression.Constant(3d)));

			Assert.AreEqual("((a + 3) / (a + 3))", body.ToString());
			Assert.AreEqual("1", body.Reduce().ToString());
		}
		
		[TestMethod]
		public void ReduceWithNestedPowers()
		{
			// a => (((a + 3) ^ 0.5) ^ 0.5)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Power(
				Expression.Power(
					Expression.Add(parameter, Expression.Constant(3d)),
					Expression.Constant(0.5d)),
				Expression.Constant(0.5d));

			Assert.AreEqual("(((a + 3) ^ 0.5) ^ 0.5)", body.ToString());
			Assert.AreEqual("((a + 3) ^ 0.25)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceSimpleExpressionWithUnnecessarySubtractionOfZeros()
		{
			// a => (((a * 3) - 0) - 0)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Subtract( 
				Expression.Subtract(
					Expression.Multiply(
						parameter,
						Expression.Constant(3d)),
					Expression.Constant(0d)),
				Expression.Constant(0d));

			Assert.AreEqual("(((a * 3) - 0) - 0)", body.ToString());
			Assert.AreEqual("(a * 3)", body.Reduce().ToString());
		}
		
		[TestMethod]
		public void ReduceComplexExpressionWithUnnecessarySubtractionOfZeros()
		{
			// a => ((-13 / (-74 / ((((((a + 43) ^ 0.25) - 0) - 0) ^ a) + 81))) - -39)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Subtract(
				Expression.Divide(
					Expression.Constant(-13d),
					Expression.Divide(
						Expression.Constant(-74d),
						Expression.Add(
							Expression.Power(
								Expression.Subtract(
									Expression.Subtract(
										Expression.Power(
											Expression.Add(
												parameter, Expression.Constant(43d)),
											Expression.Constant(0.25)),
										Expression.Constant(0d)),
									Expression.Constant(0d)),
								parameter),
							Expression.Constant(81d)))),
				Expression.Constant(-39d));

			Assert.AreEqual("((-13 / (-74 / ((((((a + 43) ^ 0.25) - 0) - 0) ^ a) + 81))) - -39)", body.ToString());
			Assert.AreEqual("((-13 / (-74 / ((((a + 43) ^ 0.25) ^ a) + 81))) - -39)", body.Reduce().ToString());
		}
		
		[TestMethod]
		public void ReduceComplexExpressionForSubtractingSameValues()
		{
			// a => ((83 + ((((-32 - a) - (-32 - a)) - ((-32 - a) - (-32 - a))) + -76)) - a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Subtract(
				Expression.Add(
					Expression.Constant(83d),
					Expression.Add(
						Expression.Subtract(
							Expression.Subtract(
								Expression.Subtract(Expression.Constant(-32d), parameter),
								Expression.Subtract(Expression.Constant(-32d), parameter)),			
							Expression.Subtract(
								Expression.Subtract(Expression.Constant(-32d), parameter),
								Expression.Subtract(Expression.Constant(-32d), parameter))),
						Expression.Constant(-76d))),
				parameter);

			Assert.AreEqual("((83 + ((((-32 - a) - (-32 - a)) - ((-32 - a) - (-32 - a))) + -76)) - a)", body.ToString());
			Assert.AreEqual("(7 - a)", body.Reduce().ToString());
		}
		
		[TestMethod]
		public void ReduceComplexExpressionWithManyConstants()
		{
			// a => (((((-33 / -73) - -26) ^ 0.5) ^ 0.5) + ((11 - a) ^ 0.5))
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Add(
				Expression.Power(
					Expression.Power(
						Expression.Subtract(
							Expression.Divide(Expression.Constant(-33d), Expression.Constant(-73d)),
							Expression.Constant(-26d)),
						Expression.Constant(.5)),
					Expression.Constant(.5)),
					Expression.Power(
						Expression.Subtract(Expression.Constant(11d), parameter),
						Expression.Constant(.5)));

			Assert.AreEqual("(((((-33 / -73) - -26) ^ 0.5) ^ 0.5) + ((11 - a) ^ 0.5))", body.ToString());
			Assert.AreEqual("(2.26785275364294 + ((11 - a) ^ 0.5))", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithAddingOfZeroOnLeft()
		{
			// (a + 0)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Add(parameter, Expression.Constant(0d));

			Assert.AreEqual("(a + 0)", body.ToString());
			Assert.AreEqual("a", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithAddingOfZeroOnRight()
		{
			// (0 + a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Add(Expression.Constant(0d), parameter);

			Assert.AreEqual("(0 + a)", body.ToString());
			Assert.AreEqual("a", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithAddingOfConstantsOnLeft()
		{
			// ((3.4 + 7.2) * a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(
				Expression.Add(
					Expression.Constant(3.4d),
					Expression.Constant(7.2d)), parameter);

			Assert.AreEqual("((3.4 + 7.2) * a)", body.ToString());
			Assert.AreEqual("(10.6 * a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithAddingOfConstantsOnRight()
		{
			// (a * (3.4 + 7.2))
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(parameter,
				Expression.Add(
					Expression.Constant(3.4d),
					Expression.Constant(7.2d)));

			Assert.AreEqual("(a * (3.4 + 7.2))", body.ToString());
			Assert.AreEqual("(a * 10.6)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithAddingOfParameters()
		{
			// (a + a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Add(parameter, parameter);

			Assert.AreEqual("(a + a)", body.ToString());
			Assert.AreEqual("(a + a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithDividingOfConstantsOnLeft()
		{
			// ((3.4 / 2) * a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(
				Expression.Divide(
					Expression.Constant(3.4d),
					Expression.Constant(2.0d)), parameter);

			Assert.AreEqual("((3.4 / 2) * a)", body.ToString());
			Assert.AreEqual("(1.7 * a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithDividingOfConstantsOnRight()
		{
			// (a * (3.4 / 2))
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(parameter,
				Expression.Divide(
					Expression.Constant(3.4d),
					Expression.Constant(2.0d)));

			Assert.AreEqual("(a * (3.4 / 2))", body.ToString());
			Assert.AreEqual("(a * 1.7)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithDividingOfParameters()
		{
			// (a / b)
			var parameterA = Expression.Parameter(typeof(double), "a");
			var parameterB = Expression.Parameter(typeof(double), "b");
			var body = Expression.Divide(parameterA, parameterB);

			Assert.AreEqual("(a / b)", body.ToString());
			Assert.AreEqual("(a / b)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithMultiplyingOfZeroOnLeft()
		{
			// (a * 0)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(parameter, Expression.Constant(0d));

			Assert.AreEqual("(a * 0)", body.ToString());
			Assert.AreEqual("0", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithMultiplyingOfZeroOnRight()
		{
			// (0 * a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(Expression.Constant(0d), parameter);

			Assert.AreEqual("(0 * a)", body.ToString());
			Assert.AreEqual("0", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithMultiplyingOfConstantsOnLeft()
		{
			// ((3.4 * 2) * a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(
				Expression.Multiply(
					Expression.Constant(3.4d),
					Expression.Constant(2.0d)), parameter);

			Assert.AreEqual("((3.4 * 2) * a)", body.ToString());
			Assert.AreEqual("(6.8 * a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithMultiplyingOfConstantsOnRight()
		{
			// (a * (3.4 * 2))
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(parameter,
				Expression.Multiply(
					Expression.Constant(3.4d),
					Expression.Constant(2.0d)));

			Assert.AreEqual("(a * (3.4 * 2))", body.ToString());
			Assert.AreEqual("(a * 6.8)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithMultiplyingOfParameters()
		{
			// (a * a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(parameter, parameter);

			Assert.AreEqual("(a * a)", body.ToString());
			Assert.AreEqual("(a * a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithPowerOfConstantsOnLeft()
		{
			// ((3.4 ^ 2) * a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(
				Expression.Power(
					Expression.Constant(3.4d),
					Expression.Constant(2.0d)), parameter);

			Assert.AreEqual("((3.4 ^ 2) * a)", body.ToString());
			Assert.AreEqual("(11.56 * a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithPowerOfConstantsOnRight()
		{
			// (a * (3.4 ^ 2))
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(parameter,
				Expression.Power(
					Expression.Constant(3.4d),
					Expression.Constant(2.0d)));

			Assert.AreEqual("(a * (3.4 ^ 2))", body.ToString());
			Assert.AreEqual("(a * 11.56)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithPowerOfParameters()
		{
			// (a ^ a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Power(parameter, parameter);

			Assert.AreEqual("(a ^ a)", body.ToString());
			Assert.AreEqual("(a ^ a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithSubtractingOfZeroOnLeft()
		{
			// (a - 0)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Subtract(parameter, Expression.Constant(0d));

			Assert.AreEqual("(a - 0)", body.ToString());
			Assert.AreEqual("a", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithSubtractingOfZeroOnRight()
		{
			// (0 - a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Subtract(Expression.Constant(0d), parameter);

			Assert.AreEqual("(0 - a)", body.ToString());
			Assert.AreEqual("(-1 * a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithSubtractingWithSameExpressionOnBothSides()
		{
			// ((a + 3) - (a + 3))
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Subtract(
				Expression.Add(parameter, Expression.Constant(3d)), 
				Expression.Add(parameter, Expression.Constant(3d)));

			Assert.AreEqual("((a + 3) - (a + 3))", body.ToString());
			Assert.AreEqual("0", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithSubtractingOfConstantsOnLeft()
		{
			// ((3.4 - 2) * a)
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(
				Expression.Subtract(
					Expression.Constant(3.4d),
					Expression.Constant(2.0d)), parameter);

			Assert.AreEqual("((3.4 - 2) * a)", body.ToString());
			Assert.AreEqual("(1.4 * a)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithSubtractingOfConstantsOnRight()
		{
			// (a * (3.4 - 2))
			var parameter = Expression.Parameter(typeof(double), "a");
			var body = Expression.Multiply(parameter,
				Expression.Subtract(
					Expression.Constant(3.4d),
					Expression.Constant(2.0d)));

			Assert.AreEqual("(a * (3.4 - 2))", body.ToString());
			Assert.AreEqual("(a * 1.4)", body.Reduce().ToString());
		}

		[TestMethod]
		public void ReduceWithSubtractingOfParameters()
		{
			// (a - b)
			var parameterA = Expression.Parameter(typeof(double), "a");
			var parameterB = Expression.Parameter(typeof(double), "b");
			var body = Expression.Subtract(parameterA, parameterB);

			Assert.AreEqual("(a - b)", body.ToString());
			Assert.AreEqual("(a - b)", body.Reduce().ToString());
		}
	}
}
