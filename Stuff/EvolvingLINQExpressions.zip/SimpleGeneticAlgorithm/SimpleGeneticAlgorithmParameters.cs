﻿using GeneticAlgorithm;
using Spackle;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace SimpleGeneticAlgorithm
{
	public sealed class SimpleGeneticAlgorithmParameters : IGeneticAlgorithmParameters<string>
	{
		private const int ChromosomeLengthValue = 20;
		private const double CrossoverProbabilityValue = 0.7;
		private const int GenerationCountValue = 200;
		private const double MutationProbabilityValue = 0.001;
		private const int ParentCount = 2;
		private static readonly int PopulationSizeValue = 200;
		private const int RunCountValue = 100;

		private SecureRandom random = new SecureRandom();

		public ReadOnlyCollection<string> Crossover(ReadOnlyCollection<Chromosome<string>> parents)
		{
			var crossoverPoint = this.random.Next(this.ChromosomeLength);

			return new List<string>()
				{ 
					parents[0].Value.Substring(0, crossoverPoint) + parents[1].Value.Substring(crossoverPoint),
					parents[1].Value.Substring(0, crossoverPoint) + parents[0].Value.Substring(crossoverPoint) 
				}.AsReadOnly();
		}

		public double FitnessEvaluator(string chromosome)
		{
			var fitness = 0d;

			foreach(var allele in chromosome)
			{
				if(allele == '1')
				{
					fitness++;
				}
			}

			return fitness;
		}

		public string Mutator(string chromosome)
		{
			var mutatedChromosome = new StringBuilder();

			foreach(char allele in chromosome)
			{
				if(this.random.NextDouble() < this.MutationProbability)
				{
					mutatedChromosome.Append(allele == '1' ? '0' : '1');
				}
				else
				{
					mutatedChromosome.Append(allele);
				}
			}

			return mutatedChromosome.ToString();
		}

		public Population<string> GeneratePopulation()
		{
			var chromosomes = new List<Chromosome<string>>();

			for(var i = 0; i < this.PopulationSize; i++)
			{
				var chromosome = new StringBuilder();

				for(var j = 0; j < this.ChromosomeLength; j++)
				{
					chromosome.Append(this.random.Next(2).ToString());
				}

				var value = chromosome.ToString();

				chromosomes.Add(new Chromosome<string>(value, this.FitnessEvaluator));
			}

			return new Population<string>(chromosomes);
		}

		public ReadOnlyCollection<Chromosome<string>> SelectFittestChildren(Population<string> population)
		{
			return new ReadOnlyCollection<Chromosome<string>>(new List<Chromosome<string>>());
		}
		
		public ReadOnlyCollection<Chromosome<string>> SelectParents(Population<string> population)
		{
			var parents = new List<Chromosome<string>>();

			for(var i = 0; i < SimpleGeneticAlgorithmParameters.ParentCount; i++)
			{
				var fitnessWeightSelection = this.random.NextDouble();
				var parent = (from value in population.Chromosomes
								  where value.FitnessWeight.Contains(fitnessWeightSelection)
								  select value.Chromosome).FirstOrDefault();
				parents.Add(parent);
			}

			return parents.AsReadOnly();
		}

		public Chromosome<string> Terminator(Population<string> population)
		{
			return (from value in population.Chromosomes
					  where value.Chromosome.Fitness == this.ChromosomeLength
					  select value.Chromosome).FirstOrDefault();
		}

		public int ChromosomeLength
		{
			get
			{
				return SimpleGeneticAlgorithmParameters.ChromosomeLengthValue;
			}
		}

		public double CrossoverProbability
		{
			get
			{
				return SimpleGeneticAlgorithmParameters.CrossoverProbabilityValue;
			}
		}

		public double MutationProbability
		{
			get
			{
				return SimpleGeneticAlgorithmParameters.MutationProbabilityValue;
			}
		}

		public int NumberOfGenerations
		{
			get
			{
				return SimpleGeneticAlgorithmParameters.GenerationCountValue;
			}
		}

		public int NumberOfGenerationRuns
		{
			get
			{
				return SimpleGeneticAlgorithmParameters.RunCountValue;
			}
		}

		public int PopulationSize
		{
			get
			{
				return SimpleGeneticAlgorithmParameters.PopulationSizeValue;
			}
		}
	}
}
