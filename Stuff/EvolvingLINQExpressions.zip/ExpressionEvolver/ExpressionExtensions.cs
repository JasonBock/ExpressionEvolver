﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace ExpressionEvolver
{
	public static class ExpressionExtensions
	{
		public static Expression GetNode(this Expression @this, int location, ref int currentCount)
		{
			Expression node = null;

			if(currentCount == location)
			{
				node = @this;
			}
			else if(@this.NodeType == ExpressionType.Lambda)
			{
				node = (@this as LambdaExpression).Body.GetNode(location, ref currentCount);
			}
			else if(typeof(BinaryExpression).IsAssignableFrom(@this.GetType()))
			{
				currentCount++;
				var binary = @this as BinaryExpression;

				node = binary.Left.GetNode(location, ref currentCount);

				if(node == null)
				{
					currentCount++;
					node = binary.Right.GetNode(location, ref currentCount);
				}
			}
			else if(@this.NodeType == ExpressionType.Parameter)
			{
				if(currentCount == location)
				{
					node = @this;
				}
			}

			return node;
		}

		public static int GetNodeCount(this Expression @this)
		{
			var count = 0;

			if(@this.NodeType == ExpressionType.Lambda)
			{
				count += (@this as LambdaExpression).Body.GetNodeCount();
			}
			else if(typeof(BinaryExpression).IsAssignableFrom(@this.GetType()))
			{
				count++;
				var binary = @this as BinaryExpression;

				count += binary.Left.GetNodeCount();
				count += binary.Right.GetNodeCount();
			}
			else if(@this.NodeType == ExpressionType.Parameter ||
				@this.NodeType == ExpressionType.Constant)
			{
				count++;
			}

			return count;
		}

		public static Expression Reduce(this Expression @this)
		{
			var reduced = @this;

			if(typeof(BinaryExpression).IsAssignableFrom(reduced.GetType()))
			{
				var binary = reduced as BinaryExpression;

				reduced = ExpressionExtensions.HandleBothConstantsCase(reduced, binary);
				reduced = ExpressionExtensions.HandlePowerReductionCase(reduced, binary);
				reduced = ExpressionExtensions.HandleSubtractionOfSameValuesCase(reduced, binary);
				reduced = ExpressionExtensions.HandleDivideOfSameValuesCase(reduced, binary);
				reduced = ExpressionExtensions.HandleAddOfZero(reduced, binary);
				reduced = ExpressionExtensions.HandleSubtractOfZero(reduced, binary);
				reduced = ExpressionExtensions.HandleMultiplyOfZero(reduced, binary);

				if(reduced is BinaryExpression)
				{
					binary = reduced as BinaryExpression;

					if(binary.Left.NodeType != ExpressionType.Constant &&
						binary.Left.NodeType != ExpressionType.Parameter)
					{
						reduced = (BinaryExpression)binary.Replace(binary.Left, binary.Left.Reduce());
					}

					binary = reduced as BinaryExpression;

					if(binary.Right.NodeType != ExpressionType.Constant &&
						binary.Right.NodeType != ExpressionType.Parameter)
					{
						reduced = (BinaryExpression)binary.Replace(binary.Right, binary.Right.Reduce());
					}

					if(binary.Left.NodeType == ExpressionType.Constant &&
						binary.Right.NodeType == ExpressionType.Constant)
					{
						reduced = reduced.Reduce();
					}									
				}
			}		
			
			if(@this.ToString() != reduced.ToString())
			{
				reduced = reduced.Reduce();
			}
			
			return reduced;
		}

		public static Expression Replace(this Expression @this, Expression find, Expression replace)
		{
			var replaceExpression = ExprOp.Visit.Chain(
				(self, last, expr) =>
				{
					if(expr == find)
					{
						return replace;
					}
					else
					{
						return last(expr);
					}
				});

			return replaceExpression(@this);
		}

		private static Expression HandleAddOfZero(Expression reduced, BinaryExpression binary)
		{
			if(binary.NodeType == ExpressionType.Add &&
				((binary.Left.NodeType == ExpressionType.Constant &&
					(double)((binary.Left as ConstantExpression).Value) == 0d) ||
				(binary.Right.NodeType == ExpressionType.Constant &&
					(double)((binary.Right as ConstantExpression).Value) == 0d)))
			{
				reduced = binary.Left.NodeType == ExpressionType.Constant ?
					binary.Right : binary.Left;
			}
			return reduced;
		}

		private static Expression HandleSubtractOfZero(Expression reduced, BinaryExpression binary)
		{
			if(binary.NodeType == ExpressionType.Subtract &&
				((binary.Left.NodeType == ExpressionType.Constant &&
					(double)((binary.Left as ConstantExpression).Value) == 0d) ||
				(binary.Right.NodeType == ExpressionType.Constant &&
					(double)((binary.Right as ConstantExpression).Value) == 0d)))
			{
				reduced = binary.Left.NodeType == ExpressionType.Constant ?
					Expression.Multiply(Expression.Constant(-1d), binary.Right) : binary.Left;
			}
			return reduced;
		}

		private static Expression HandleMultiplyOfZero(Expression reduced, BinaryExpression binary)
		{
			if(binary.NodeType == ExpressionType.Multiply &&
				((binary.Left.NodeType == ExpressionType.Constant &&
					(double)((binary.Left as ConstantExpression).Value) == 0d) ||
				(binary.Right.NodeType == ExpressionType.Constant &&
					(double)((binary.Right as ConstantExpression).Value) == 0d)))
			{
				reduced = Expression.Constant(0d);
			}
			return reduced;
		}

		private static Expression HandleDivideOfSameValuesCase(Expression reduced, BinaryExpression binary)
		{
			if(binary.NodeType == ExpressionType.Divide &&
				binary.Left.ToString() == binary.Right.ToString())
			{
				reduced = Expression.Constant(1d);
			}
			return reduced;
		}

		private static Expression HandleSubtractionOfSameValuesCase(Expression reduced, BinaryExpression binary)
		{
			if(binary.NodeType == ExpressionType.Subtract &&
				binary.Left.ToString() == binary.Right.ToString())
			{
				reduced = Expression.Constant(0d);
			}
			return reduced;
		}

		private static Expression HandlePowerReductionCase(Expression reduced, BinaryExpression binary)
		{
			if(binary.NodeType == ExpressionType.Power &&
				binary.Right.NodeType == ExpressionType.Constant &&
				binary.Left.NodeType == ExpressionType.Power &&
				(binary.Left as BinaryExpression).Right.NodeType == ExpressionType.Constant)
			{
				reduced = Expression.Power((binary.Left as BinaryExpression).Left,
						Expression.Constant(
							(double)((binary.Right as ConstantExpression).Value) *
							(double)(((binary.Left as BinaryExpression).Right as ConstantExpression).Value)));
			}
			return reduced;
		}

		private static Expression HandleBothConstantsCase(Expression reduced, BinaryExpression binary)
		{
			if(binary.Left.NodeType == ExpressionType.Constant &&
				binary.Right.NodeType == ExpressionType.Constant)
			{
				double leftValue = (double)(binary.Left as ConstantExpression).Value;
				double rightValue = (double)(binary.Right as ConstantExpression).Value;
				ConstantExpression constant = null;

				switch(binary.NodeType)
				{
					case ExpressionType.Add:
						constant = Expression.Constant(leftValue + rightValue);
						break;
					case ExpressionType.Subtract:
						constant = Expression.Constant(leftValue - rightValue);
						break;
					case ExpressionType.Multiply:
						constant = Expression.Constant(leftValue * rightValue);
						break;
					case ExpressionType.Divide:
						constant = Expression.Constant(leftValue / rightValue);
						break;
					case ExpressionType.Power:
						constant = Expression.Constant(Math.Pow(leftValue, rightValue));
						break;
					default:
						throw new NotSupportedException("Unexpected expression type.");
				}

				reduced = constant;
			}
			return reduced;
		}
	}
}
