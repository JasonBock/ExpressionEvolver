﻿using GeneticAlgorithm;
using Spackle;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;

namespace ExpressionEvolver
{
	public sealed class ExpressionEvolverGeneticAlgorithmParameters
		: IGeneticAlgorithmParameters<Expression<Func<double, double>>>
	{
		private enum Operators
		{
			Add,
			Subtract,
			Multiply,
			Divide,
			SquareRoot,
			Power
		}

		private const int ConstantVariance = 100;
		private const double CrossoverProbabilityValue = 0.9;
		private const int ExpressionMaximum = 5;
		private const int GenerationCountValue = 100;
		private const double InjectConstantProbabilityValue = 0.5;
		private const double MutationProbabilityValue = 0.001;
		private static readonly int NodeMaximumPenaltyThreshold = (int)Math.Pow(3d, 
			(double)ExpressionEvolverGeneticAlgorithmParameters.ExpressionMaximum);
		private const int ParentCount = 2;
		private const int PopulationSizeValue = 2000;
		private const int ResultGenerationCount = 100;
		private const double ResultGenerationVariance = 1d;
		private const int RunCountValue = 100;
		private const double SelectFittestChildrenPercentage = 10d;

		private SecureRandom random = new SecureRandom();
		private ReadOnlyCollection<ExpressionEvolverResult> results;

		public ExpressionEvolverGeneticAlgorithmParameters(Func<double, double> target)
			: base()
		{
			this.GenerateResults(target,
				ExpressionEvolverGeneticAlgorithmParameters.ResultGenerationCount,
				ExpressionEvolverGeneticAlgorithmParameters.ResultGenerationVariance);
		}

		public ExpressionEvolverGeneticAlgorithmParameters(Func<double, double> target,
			int count, double variance)
			: base()
		{
			this.GenerateResults(target, count, variance);
		}

		public ExpressionEvolverGeneticAlgorithmParameters(ReadOnlyCollection<ExpressionEvolverResult> results)
			: base()
		{
			this.results = results;
		}

		private void GenerateResults(Func<double, double> target, int count, double variance)
		{
			var targetResults = new List<ExpressionEvolverResult>();

			do
			{
				var parameter = this.random.NextDouble() * variance *
					(this.random.NextBoolean() ? 1d : -1d);

				try
				{
					var result = target(parameter);

					if(!double.IsNaN(result) && !double.IsInfinity(result))
					{
						targetResults.Add(new ExpressionEvolverResult(parameter, result));
					}
				}
				catch(ArithmeticException e)
				{
					targetResults.Add(new ExpressionEvolverResult(parameter, e));
				}
			} while(targetResults.Count < count);

			this.results = targetResults.AsReadOnly();
		}

		private Expression GetRandomOperation(Expression expression, Operators @operator)
		{
			Expression operation = null;

			if(@operator == Operators.SquareRoot)
			{
				operation = Expression.Power(expression, Expression.Constant(0.5d));
			}
			else
			{
				bool isLeftConstant = this.random.NextDouble() < ExpressionEvolverGeneticAlgorithmParameters.InjectConstantProbabilityValue;
				bool isRightConstant = this.random.NextDouble() < ExpressionEvolverGeneticAlgorithmParameters.InjectConstantProbabilityValue;

				if(isLeftConstant && isRightConstant ||
					(@operator == Operators.Divide && !isLeftConstant && !isRightConstant))
				{
					isLeftConstant = this.random.NextBoolean();
					isRightConstant = !isLeftConstant;
				}

				Func<Expression, Expression, Expression> selectedOperation = null;

				switch(@operator)
				{
					case Operators.Add:
						selectedOperation = Expression.Add;
						break;
					case Operators.Subtract:
						selectedOperation = Expression.Subtract;
						break;
					case Operators.Multiply:
						selectedOperation = Expression.Multiply;
						break;
					case Operators.Divide:
						selectedOperation = Expression.Divide;
						break;
					default:
						throw new NotSupportedException();
				}

				operation = selectedOperation(
					isLeftConstant ? this.GetConstant() : expression,
					isRightConstant ? this.GetConstant() : expression);
			}

			return operation;
		}

		private ConstantExpression GetConstant()
		{
			var value = (double)(this.random.Next(1, ExpressionEvolverGeneticAlgorithmParameters.ConstantVariance) *
				(this.random.NextBoolean() ? -1 : 1));
			return Expression.Constant(value);
		}

		public ReadOnlyCollection<Expression<Func<double, double>>> Crossover(
			ReadOnlyCollection<Chromosome<Expression<Func<double, double>>>> parents)
		{
			var children = new List<Expression<Func<double, double>>>();

			var first = parents[0];
			var second = parents[1];
			var firstCount = first.Value.Body.GetNodeCount();
			var secondCount = second.Value.Body.GetNodeCount();

			var firstCrossoverPoint = this.random.Next(firstCount);
			var secondCrossoverPoint = this.random.Next(secondCount);

			var firstCurrentCount = 0;
			var secondCurrentCount = 0;
			var firstExpression = first.Value.Body.GetNode(firstCrossoverPoint, ref firstCurrentCount);
			var secondExpression = second.Value.Body.GetNode(secondCrossoverPoint, ref secondCurrentCount);

			var newFirst = first.Value.Body.Replace(firstExpression, secondExpression).Reduce()
				.Replace(second.Value.Parameters[0], first.Value.Parameters[0]);
						
			var newSecond = second.Value.Body.Replace(secondExpression, firstExpression).Reduce()
				.Replace(first.Value.Parameters[0], second.Value.Parameters[0]);

			children.Add(Expression.Lambda<Func<double, double>>(newFirst,
				first.Value.Parameters));
			children.Add(Expression.Lambda<Func<double, double>>(newSecond,
				second.Value.Parameters));

			return children.AsReadOnly();
		}

		public double FitnessEvaluator(Expression<Func<double, double>> chromosome)
		{
			var fitness = 0d;
			var phenotype = chromosome.Compile();

			foreach(var result in this.results)
			{
				try
				{
					var calculation = phenotype(result.Parameter);

					if(result.Exception == null && !Double.IsNaN(calculation))
					{
						var currentFitness = Math.Abs((result.Result - calculation) / result.Result) * 100;

						if(currentFitness < ExpressionEvolverGeneticAlgorithmParameters.ResultGenerationVariance)
						{
							fitness++;
						}
					}
				}
				catch(ArithmeticException)
				{
					if(result.Exception != null)
					{
						fitness++;
					}
				}
			}

			if(chromosome.GetNodeCount() > ExpressionEvolverGeneticAlgorithmParameters.NodeMaximumPenaltyThreshold)
			{
				var sizePenalty = (int)Math.Exp(Math.Pow((double)(chromosome.GetNodeCount() -
					ExpressionEvolverGeneticAlgorithmParameters.NodeMaximumPenaltyThreshold), 0.1));
				fitness -= sizePenalty;
				
				if(fitness < 0)
				{
					fitness = 0;
				}
			}
			
			return fitness;
		}

		public Expression<Func<double, double>> Mutator(Expression<Func<double, double>> chromosome)
		{
			Expression<Func<double, double>> mutated = null;

			if(this.random.NextDouble() < this.MutationProbability)
			{
				var chromosomeBody = chromosome.Body;
				var nodeCount = chromosomeBody.GetNodeCount();
				var selectedNodeIndex = this.random.Next(nodeCount);
				var currentCount = 0;
				var selectedNode = chromosomeBody.GetNode(selectedNodeIndex, ref currentCount);
				var selectedNodeCount = selectedNode.GetNodeCount();
				var mutatedNode = this.GenerateRandomBody(
					this.random.Next(selectedNodeCount * 2), chromosome.Parameters[0]);

				chromosomeBody = chromosomeBody.Replace(selectedNode, mutatedNode).Reduce();
				
				mutated = Expression.Lambda<Func<double, double>>(chromosomeBody,
					(from param in chromosome.Parameters
					 select param));
			}
			else
			{
				mutated = chromosome;
			}

			return mutated;
		}

		public Population<Expression<Func<double, double>>> GeneratePopulation()
		{
			var chromosomes = new List<Chromosome<Expression<Func<double, double>>>>();

			for(var i = 0; i < ExpressionEvolverGeneticAlgorithmParameters.PopulationSizeValue; i++)
			{
				var parameter = Expression.Parameter(typeof(double), "a");
				var maximumExpressions = this.random.Next(
					ExpressionEvolverGeneticAlgorithmParameters.ExpressionMaximum);

				Expression body = this.GenerateRandomBody(maximumExpressions, parameter).Reduce();

				chromosomes.Add(new Chromosome<Expression<Func<double, double>>>(
					Expression.Lambda<Func<double, double>>(body, parameter), this.FitnessEvaluator));
			}

			return new Population<Expression<Func<double, double>>>(chromosomes);
		}

		private Expression GenerateRandomBody(int maximumOperationCount, ParameterExpression parameter)
		{
			Expression body = parameter;

			for(var x = 0; x < maximumOperationCount; x++)
			{
				body = this.GetRandomOperation(body,
					(Operators)this.random.Next((int)Operators.SquareRoot + 1));
			}

			return body;
		}

		public ReadOnlyCollection<Chromosome<Expression<Func<double, double>>>> SelectFittestChildren(
			Population<Expression<Func<double, double>>> population)
		{
			return new ReadOnlyCollection<Chromosome<Expression<Func<double, double>>>>(
				new List<Chromosome<Expression<Func<double, double>>>>((
					from value in population.Chromosomes
					orderby value.Chromosome.Fitness descending
					select value.Chromosome).Take(
						(int)((double)population.Chromosomes.Count / ExpressionEvolverGeneticAlgorithmParameters.SelectFittestChildrenPercentage))));
		}

		public ReadOnlyCollection<Chromosome<Expression<Func<double, double>>>> SelectParents(
			Population<Expression<Func<double, double>>> population)
		{
			var parents = new List<Chromosome<Expression<Func<double, double>>>>();

			for(var i = 0; i < ExpressionEvolverGeneticAlgorithmParameters.ParentCount; i++)
			{
				var fitnessWeightSelection = this.random.NextDouble();
				var parent = (from value in population.Chromosomes
								  where value.FitnessWeight.Contains(fitnessWeightSelection)
								  select value.Chromosome).FirstOrDefault();
				parents.Add(parent);
			}

			return parents.AsReadOnly();
		}

		public Chromosome<Expression<Func<double, double>>> Terminator(
			Population<Expression<Func<double, double>>> population)
		{
			return (from value in population.Chromosomes
					  where value.Chromosome.Fitness >= this.results.Count
					  select value.Chromosome).FirstOrDefault();
		}

		public int ChromosomeLength
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public double CrossoverProbability
		{
			get
			{
				return ExpressionEvolverGeneticAlgorithmParameters.CrossoverProbabilityValue;
			}
		}

		public double MutationProbability
		{
			get
			{
				return ExpressionEvolverGeneticAlgorithmParameters.MutationProbabilityValue;
			}
		}

		public int NumberOfGenerations
		{
			get
			{
				return ExpressionEvolverGeneticAlgorithmParameters.GenerationCountValue;
			}
		}

		public int NumberOfGenerationRuns
		{
			get
			{
				return ExpressionEvolverGeneticAlgorithmParameters.RunCountValue;
			}
		}

		public int PopulationSize
		{
			get
			{
				return ExpressionEvolverGeneticAlgorithmParameters.PopulationSizeValue;
			}
		}
	}
}
