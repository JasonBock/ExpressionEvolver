﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("www.jasonbock.net")]
[assembly: AssemblyCopyright("Copyright © jasonbock.net 2010")]
[assembly: AssemblyDescription("An assembly that contains the simple bit-string GA.")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("SimpleGeneticAlgorithm")]
[assembly: AssemblyTitle("SimpleGeneticAlgorithm")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]